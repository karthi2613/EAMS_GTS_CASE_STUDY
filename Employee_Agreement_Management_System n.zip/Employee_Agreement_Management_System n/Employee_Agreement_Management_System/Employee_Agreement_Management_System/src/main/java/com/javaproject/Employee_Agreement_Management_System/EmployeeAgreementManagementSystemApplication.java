package com.javaproject.Employee_Agreement_Management_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAgreementManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAgreementManagementSystemApplication.class, args);
	}

}
